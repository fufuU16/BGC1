/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u537987570_bgc_database
-- ------------------------------------------------------
-- Server version	10.11.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES
(1,3,'Test12345','User logged in','2024-11-25 02:24:34',NULL,NULL),
(2,3,'Test12345','User logged in','2024-11-25 02:54:36',NULL,NULL),
(3,3,'Test12345','User logged in','2024-11-25 02:55:15',NULL,NULL),
(4,3,'Test12345','User logged in','2024-11-25 02:57:24',NULL,NULL),
(5,3,'Test12345','User logged in','2024-11-25 02:57:48',NULL,NULL),
(6,3,'Test12345','User logged in','2024-11-25 03:00:18',NULL,NULL),
(7,3,'Test12345','User logged in','2024-11-25 03:02:55',NULL,NULL),
(8,3,'Test12345','User logged in','2024-11-25 03:03:52',NULL,NULL),
(9,3,'Test12345','User logged in','2024-11-25 03:04:33',NULL,NULL),
(10,3,'Test12345','User logged in','2024-11-25 03:06:27',NULL,NULL),
(11,3,'Test12345','User logged in','2024-11-25 03:08:07',NULL,NULL),
(12,3,'Test12345','User logged in','2024-11-25 03:08:45',NULL,NULL),
(13,3,'Test12345','User logged in','2024-11-25 03:14:07',NULL,NULL),
(14,3,'Test12345','User logged out','2024-11-25 03:14:10',NULL,NULL),
(15,3,'Test12345','User logged in','2024-11-25 03:25:22',NULL,NULL),
(16,3,'Test12345','User logged in','2024-11-25 14:48:35',NULL,NULL),
(17,3,'Test12345','User logged in','2024-11-26 00:51:16',NULL,NULL),
(18,3,'Test12345','User logged in','2025-02-25 21:36:18',NULL,NULL),
(19,3,'Test12345','User logged out','2025-02-25 21:36:55',NULL,NULL),
(20,3,'Test12345','User logged in','2025-02-25 21:37:12',NULL,NULL),
(21,3,'Test12345','User logged out','2025-02-25 21:37:14',NULL,NULL),
(22,3,'Test12345','User logged in','2025-02-25 21:38:18',NULL,NULL),
(23,3,'Test12345','User logged out','2025-02-25 21:39:47',NULL,NULL),
(24,3,'Test12345','User logged in','2025-02-25 21:41:05',NULL,NULL),
(25,3,'Test12345','User logged out','2025-02-25 21:45:37',NULL,NULL),
(26,3,'Test12345','User logged in','2025-02-25 21:47:03',NULL,NULL),
(27,3,'Test12345','User logged in','2025-03-03 19:51:42',NULL,NULL),
(28,3,'Test12345','User logged in','2025-03-04 01:30:24',NULL,NULL),
(29,3,'Test12345','User logged out','2025-03-04 01:30:30',NULL,NULL),
(30,3,'Test12345','User logged in','2025-03-04 01:33:56',NULL,NULL),
(31,3,'Test12345','User logged out','2025-03-04 01:34:36',NULL,NULL),
(32,3,'Test12345','User logged in','2025-03-04 01:39:15',NULL,NULL),
(33,3,'Test12345','User logged in','2025-03-05 22:04:08',NULL,NULL),
(34,3,'Test12345','User logged in','2025-03-05 22:19:34',NULL,NULL),
(35,3,'Test12345','User logged in','2025-03-05 22:26:11',NULL,NULL),
(36,3,'Test12345','User logged in','2025-03-05 22:53:00',NULL,NULL),
(37,3,'Test12345','User logged in','2025-03-05 23:06:14',NULL,NULL),
(38,3,'Test12345','User logged in','2025-03-05 23:08:16',NULL,NULL),
(39,3,'Test12345','User logged in','2025-03-06 12:19:31',NULL,NULL),
(40,3,'Test12345','User logged in','2025-03-08 16:16:44',NULL,NULL),
(41,3,'Test12345','User logged out','2025-03-08 16:42:59',NULL,NULL),
(42,2,'Test1234','User logged in','2025-03-08 16:43:28',NULL,NULL),
(43,2,'Test1234','User logged out','2025-03-08 16:48:55',NULL,NULL),
(44,3,'Test12345','User logged in','2025-03-08 16:56:34',NULL,NULL),
(45,3,'Test12345','User logged out','2025-03-08 16:56:37',NULL,NULL),
(46,3,'Test12345','User logged in','2025-03-08 17:01:30',NULL,NULL),
(47,3,'Test12345','User logged out','2025-03-08 17:05:03',NULL,NULL),
(48,3,'Test12345','User logged in','2025-03-08 17:40:47',NULL,NULL),
(49,3,'Test12345','User logged in','2025-03-09 22:46:44',NULL,NULL),
(50,3,'Test12345','User logged in','2025-03-10 22:49:24',NULL,NULL),
(51,3,'Test12345','User logged in','2025-03-11 11:50:25',NULL,NULL),
(52,3,'Test12345','User logged out','2025-03-11 12:32:17',NULL,NULL),
(53,3,'Test12345','User logged in','2025-03-11 12:50:51',NULL,NULL),
(54,3,'Test12345','User logged out','2025-03-11 12:50:55',NULL,NULL),
(55,3,'Test12345','User logged in','2025-03-11 13:09:42',NULL,NULL),
(56,3,'Test12345','User logged out','2025-03-11 13:09:44',NULL,NULL),
(57,3,'Test12345','User logged in','2025-03-11 13:10:47',NULL,NULL),
(58,3,'Test12345','User logged out','2025-03-11 13:10:53',NULL,NULL),
(59,3,'Test12345','User logged in','2025-03-11 13:17:19',NULL,NULL),
(60,3,'Test12345','User logged out','2025-03-11 13:17:21',NULL,NULL),
(61,3,'Test12345','User logged in','2025-03-11 21:32:50',NULL,NULL),
(62,3,'Test12345','User logged out','2025-03-11 21:34:13',NULL,NULL),
(63,3,'Test12345','User logged in','2025-03-11 21:36:28',NULL,NULL),
(64,3,'Test12345','User logged out','2025-03-11 21:37:46',NULL,NULL),
(65,3,'Test12345','User logged in','2025-03-11 21:49:11',NULL,NULL),
(66,3,'Test12345','User logged out','2025-03-11 21:50:37',NULL,NULL),
(67,3,'Test12345','User logged in','2025-03-11 21:50:42',NULL,NULL),
(68,3,'Test12345','User logged out','2025-03-11 21:50:44',NULL,NULL),
(69,3,'Test12345','User logged in','2025-03-11 21:53:39',NULL,NULL),
(70,3,'Test12345','User logged out','2025-03-11 22:35:13',NULL,NULL),
(71,3,'Test12345','User logged in','2025-03-11 22:35:54',NULL,NULL),
(72,3,'Test12345','User logged out','2025-03-11 22:38:44',NULL,NULL),
(73,7,'Test123456','User logged in','2025-03-11 22:50:57',NULL,NULL),
(74,7,'Test123456','User logged out','2025-03-11 22:51:05',NULL,NULL),
(75,7,'Test123456','User logged in','2025-03-11 22:51:13',NULL,NULL),
(76,7,'Test123456','User logged out','2025-03-11 22:51:22',NULL,NULL),
(77,7,'Test123456','User logged in','2025-03-11 22:58:27',NULL,NULL),
(78,3,'Test12345','User logged in','2025-03-12 22:40:49',NULL,NULL),
(79,3,'Test12345','User logged out','2025-03-13 00:38:30',NULL,NULL),
(80,3,'Test12345','User logged in','2025-03-13 22:55:35',NULL,NULL),
(81,3,'Test12345','User logged out','2025-03-14 02:17:47',NULL,NULL),
(82,3,'Test12345','User logged in','2025-03-14 02:25:28',NULL,NULL),
(83,3,'Test12345','User logged in','2025-03-15 01:45:47',NULL,NULL),
(84,3,'Test12345','User logged out','2025-03-15 01:45:50',NULL,NULL),
(85,3,'Test12345','User logged in','2025-03-15 02:01:05',NULL,NULL),
(86,3,'Test12345','User logged in','2025-03-15 09:39:55',NULL,NULL),
(92,3,'Test12345','Updated schedule for bus Bus05','2025-03-15 10:02:20',NULL,NULL),
(93,3,'Test12345','Added new driver: testiing','2025-03-15 10:05:46',NULL,NULL),
(94,15,'Test12345','User registered: test7622','2025-03-15 10:08:08',NULL,NULL),
(95,3,'Test12345','Updated bus details for bus ID: Bus06','2025-03-15 10:12:02',NULL,NULL),
(96,3,'Test12345','Deleted admin with ID: 14','2025-03-15 10:15:49',NULL,NULL),
(97,16,'Test12345','Registered a new user','2025-03-15 10:18:21',NULL,NULL),
(98,3,'Test12345','User logged in','2025-03-15 11:36:09','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(99,3,'Test12345','User logged in','2025-03-15 11:50:04','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(100,3,'Test12345','User logged in','2025-03-15 13:37:54','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(101,3,'Test12345','Deleted admin with ID: 13','2025-03-15 13:51:53',NULL,NULL),
(102,3,'Test12345','User logged in','2025-03-15 14:30:30','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(103,3,'Test12345','User logged out','2025-03-15 14:37:31','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(104,3,'Test12345','User logged in','2025-03-15 14:39:21','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(105,3,'Test12345','Updated bus details for bus ID: Bus03','2025-03-15 14:46:18',NULL,NULL),
(106,3,'Test12345','Updated schedule for bus Bus03','2025-03-15 14:48:05',NULL,NULL),
(107,3,'Test12345','User logged out','2025-03-15 14:54:40','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(108,3,'Test12345','User logged in','2025-03-15 21:06:51','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(109,3,'Test12345','User logged in','2025-03-16 10:28:05','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(110,3,'Test12345','User logged in','2025-03-16 12:22:00','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(111,3,'Test12345','User logged in','2025-03-16 12:47:57','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(112,3,'Test12345','User logged in','2025-03-16 13:11:03','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(113,3,'Test12345','User logged in','2025-03-16 13:41:38','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(114,3,'Test12345','User logged in','2025-03-16 14:11:16','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(115,3,'Test12345','User logged in','2025-03-16 14:47:50','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(116,3,'Test12345','User logged in','2025-03-16 15:10:45','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(117,3,'Test12345','User logged in','2025-03-17 00:14:35','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(118,3,'Test12345','User logged in','2025-03-17 14:00:03','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(119,3,'Test12345','User logged in','2025-03-17 14:18:12','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(120,3,'Test12345','Updated bus details for bus ID: Bus01','2025-03-17 15:48:40',NULL,NULL),
(121,3,'Test12345','Updated bus details for bus ID: Bus01','2025-03-17 15:49:22',NULL,NULL),
(122,3,'Test12345','Performed Tire replacement on bus ID: Bus01','2025-03-17 15:49:22',NULL,NULL),
(123,3,'Test12345','Updated bus details for bus ID: Bus06','2025-03-17 15:49:42',NULL,NULL),
(124,3,'Test12345','Updated bus details for bus ID: Bus06','2025-03-17 15:50:05',NULL,NULL),
(125,3,'Test12345','Updated bus details for bus ID: Bus04','2025-03-17 15:50:24',NULL,NULL),
(126,3,'Test12345','User logged out','2025-03-17 17:12:26','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(127,3,'Test12345','User logged in','2025-03-17 17:12:37','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(128,3,'Test12345','User logged out','2025-03-17 17:14:00','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(129,3,'Test12345','User logged in','2025-03-17 17:14:04','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(130,3,'Test12345','User logged out','2025-03-17 17:34:13','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(131,3,'Test12345','User logged in','2025-03-17 17:34:17','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(132,3,'Test12345','User logged out','2025-03-17 17:36:19','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(133,3,'Test12345','User logged in','2025-03-17 17:36:24','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(134,3,'Test12345','User logged out','2025-03-17 17:36:40','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(135,3,'Test12345','User logged in','2025-03-17 17:36:58','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(136,3,'Test12345','User logged out','2025-03-17 17:42:36','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(137,3,'Test12345','User logged in','2025-03-17 17:42:42','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(138,3,'Test12345','User logged out','2025-03-17 17:46:26','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(139,3,'Test12345','User logged in','2025-03-17 17:46:32','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(140,3,'Test12345','User logged in','2025-03-17 17:46:48','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(141,3,'Test12345','User logged in','2025-03-17 17:47:31','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(142,3,'Test12345','User logged in','2025-03-17 17:47:57','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(143,3,'Test12345','User logged out','2025-03-17 17:48:03','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(144,3,'Test12345','User logged in','2025-03-17 17:48:15','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(145,3,'Test12345','User logged out','2025-03-17 18:32:36','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(146,3,'Test12345','User logged in','2025-03-17 18:32:39','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(147,3,'Test12345','User logged out','2025-03-17 18:33:24','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(148,3,'Test12345','User logged in','2025-03-17 18:33:27','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(149,3,'Test12345','User logged in','2025-03-17 19:22:06','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(150,3,'Test12345','User logged in','2025-03-17 19:30:35','192.168.3.185','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(151,3,'Test12345','User logged in','2025-03-17 19:54:22','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(152,3,'Test12345','User logged in','2025-03-17 19:57:39','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(153,3,'Test12345','User logged out','2025-03-17 21:13:56','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(154,3,'Test12345','User logged in','2025-03-18 02:16:45','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(155,3,'Test12345','Updated bus details for bus ID: Bus01','2025-03-18 05:24:18',NULL,NULL),
(156,3,'Test12345','Performed Tire replacement on bus ID: Bus01','2025-03-18 05:24:18',NULL,NULL),
(157,3,'Test12345','User logged in','2025-03-18 10:21:47','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(158,3,'Test12345','Updated bus details for bus ID: Bus05','2025-03-18 10:27:18',NULL,NULL),
(159,3,'Test12345','User logged in','2025-03-18 10:52:28','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(160,3,'Test12345','User logged in','2025-03-18 10:53:04','112.210.232.39','Mozilla/5.0 (Linux; Android 14; en; Infinix X6731 Build/SP1A.210812.016) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.129 HiBrowser/v2.24.2.1 UWS/ Mobile Safari/537.36'),
(161,3,'Test12345','User logged in','2025-03-18 10:59:21','152.32.98.142','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(162,3,'Test12345','User logged out','2025-03-18 11:03:50','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(163,3,'Test12345','User logged in','2025-03-18 11:05:27','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(164,3,'Test12345','Registered a new user: JoshPogi','2025-03-18 11:09:07',NULL,NULL),
(166,3,'Test12345','User logged out','2025-03-18 11:11:30','152.32.98.142','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(168,3,'Test12345','User logged in','2025-03-18 11:19:29','2001:4451:8723:8900:e0e9:74:626:37e8','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(169,3,'Test12345','Deleted admin with ID: 17','2025-03-18 11:20:05',NULL,NULL),
(170,3,'Test12345','Registered a new user: Kaldrx','2025-03-18 11:20:29',NULL,NULL),
(171,3,'Test12345','User logged out','2025-03-18 11:20:50','2001:4451:8723:8900:e0e9:74:626:37e8','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(172,3,'Test12345','User logged in','2025-03-18 11:28:29','152.32.98.142','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(173,3,'Test12345','User logged out','2025-03-18 11:30:00','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(174,3,'Test12345','User logged in','2025-03-18 11:33:33','2001:4451:8723:8900:e0e9:74:626:37e8','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(175,3,'Test12345','User logged out','2025-03-18 11:34:40','2001:4451:8723:8900:e0e9:74:626:37e8','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(176,3,'Test12345','User logged in','2025-03-18 11:49:06','2001:4451:8723:8900:e0e9:74:626:37e8','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(177,3,'Test12345','User logged in','2025-03-18 11:54:41','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(178,3,'Test12345','User logged in','2025-03-18 12:03:50','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(179,3,'Test12345','User logged in','2025-03-18 12:23:50','152.32.98.142','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'),
(180,3,'Test12345','User logged in','2025-03-18 12:28:33','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(181,3,'Test12345','User logged out','2025-03-18 12:45:42','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(182,3,'Test12345','User logged in','2025-03-18 13:23:47','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(183,3,'Test12345','User logged in','2025-03-18 13:27:36','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(184,3,'Test12345','User logged in','2025-03-18 13:33:45','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(185,3,'Test12345','User logged out','2025-03-18 13:35:09','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(186,3,'Test12345','User logged in','2025-03-18 13:36:50','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(187,3,'Test12345','Deleted admin with ID: 12','2025-03-18 13:38:18',NULL,NULL),
(188,3,'Test12345','Registered a new user: Qwerty123','2025-03-18 13:39:19',NULL,NULL),
(189,3,'Test12345','Updated schedule for bus Bus03','2025-03-18 13:48:25',NULL,NULL),
(190,3,'Test12345','User logged out','2025-03-18 13:50:35','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(191,7,'Test123456','User logged in','2025-03-18 13:52:48','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(192,7,'Test123456','Registered a new user: Qwerty12345','2025-03-18 13:53:41',NULL,NULL),
(193,7,'Test123456','User logged out','2025-03-18 13:53:44','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'),
(194,3,'Test12345','User logged in','2025-03-18 13:54:44','136.158.30.239','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;

--
-- Table structure for table `bus_details`
--

DROP TABLE IF EXISTS `bus_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_details` (
  `bus_id` varchar(50) NOT NULL,
  `plate_number` varchar(20) DEFAULT NULL,
  `chassis_number` varchar(50) DEFAULT NULL,
  `engine_number` varchar(50) DEFAULT NULL,
  `seating_capacity` int(11) DEFAULT NULL,
  `route` varchar(100) DEFAULT NULL,
  `fuel_type` varchar(20) DEFAULT NULL,
  `next_scheduled_maintenance` date DEFAULT NULL,
  `last_maintenance` date DEFAULT NULL,
  `tire_replacement_date` date DEFAULT NULL,
  `battery_replacement_date` date DEFAULT NULL,
  `brake_check_date` date DEFAULT NULL,
  `driver1` varchar(100) DEFAULT NULL,
  `driver2` varchar(100) DEFAULT NULL,
  `driver1_shift` varchar(100) DEFAULT NULL,
  `driver2_shift` int(100) DEFAULT NULL,
  `daily_usage` varchar(20) DEFAULT NULL,
  `current_status` varchar(50) DEFAULT NULL,
  `registration_expiry` date DEFAULT NULL,
  `AfterMaintenanceOdometer` bigint(20) DEFAULT NULL,
  `TotalOdometer` bigint(20) DEFAULT NULL,
  `last_updated` date DEFAULT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_details`
--

/*!40000 ALTER TABLE `bus_details` DISABLE KEYS */;
INSERT INTO `bus_details` VALUES
('Bus01','XYZ-1234','CH1234567890','EN9876543210',50,'Central Route','Diesel','2025-03-13','2025-01-14','2025-02-26','2024-07-20','2024-08-10','','','morning',0,'200 km','operational','2024-01-15',12312310,12312315,NULL),
('Bus02','ABC-5678','CH0987654321','EN1234567890',45,'Weekend Route','Petrol','2025-03-13','2025-01-14','2024-05-10','2024-06-25','2024-07-30','','',NULL,NULL,'150 km','under_maintenance','2024-02-20',12312310,12312312,NULL),
('Bus03','DEF-9012','CH5678901234','EN0987654321',60,'East Route','Electric','2025-03-13','2025-01-14','2024-04-05','2024-05-15','2024-06-20','JudyMalahay','Jane Smith','morning',0,'300 km','operational','2024-03-10',123123120,123123130,NULL),
('Bus04','RS2ES4','2134252',NULL,90,NULL,NULL,'2025-03-13','2025-03-17',NULL,NULL,NULL,'','',NULL,NULL,NULL,'under_maintenance',NULL,NULL,NULL,NULL),
('Bus05','RS2ES4','2134252',NULL,90,'Central Route',NULL,'2025-03-13','2025-01-14',NULL,NULL,NULL,'','','morning',0,NULL,'operational',NULL,NULL,5342,NULL),
('Bus06','RS2ES4wqe','eqweqwe','123123123',30,'ARCA South Route','Diesel','2025-03-13','2025-03-17',NULL,NULL,NULL,'','','morning',0,NULL,'operational',NULL,NULL,1500,NULL),
('Bus07','Bus08','Cfee2','24478975',80,NULL,'Diesel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10000,NULL);
/*!40000 ALTER TABLE `bus_details` ENABLE KEYS */;

--
-- Table structure for table `bus_passenger_data`
--

DROP TABLE IF EXISTS `bus_passenger_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_passenger_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `bus_id` varchar(50) NOT NULL,
  `route` varchar(255) NOT NULL,
  `current_passengers` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_passenger_data`
--

/*!40000 ALTER TABLE `bus_passenger_data` DISABLE KEYS */;
INSERT INTO `bus_passenger_data` VALUES
(1,'2024-11-02','Bus01','Central Route',30),
(2,'2024-11-02','Bus02','North Route',25),
(3,'2024-11-02','Bus03','East Route',20),
(4,'2024-11-02','Bus01','Central Route',30),
(5,'2024-11-02','Bus02','North Route',25),
(6,'2024-11-02','Bus03','East Route',20),
(7,'2024-11-03','Bus01','Central Route',35),
(8,'2024-11-03','Bus02','North Route',28),
(9,'2024-11-03','Bus03','East Route',22),
(10,'2024-11-04','Bus01','Central Route',40),
(11,'2024-11-04','Bus02','North Route',30),
(12,'2024-11-04','Bus03','East Route',25),
(13,'2024-11-23','Bus01','Central Route',30),
(14,'2024-11-23','Bus02','North Route',25),
(16,'2024-11-23','Bus01','Central Route',35),
(17,'2024-11-23','Bus02','North Route',28),
(18,'2024-11-23','Bus03','East Route',22),
(19,'2024-11-16','Bus01','Central Route',30),
(20,'2024-11-17','Bus02','North Route',25),
(21,'2024-11-18','Bus03','East Route',20),
(22,'2024-11-19','Bus01','Central Route',35),
(23,'2024-11-20','Bus02','North Route',28),
(24,'2024-11-21','Bus03','West Route',22),
(25,'2025-02-27','Bus01','Central Route',30),
(26,'2025-02-27','Bus02','North Route',25),
(27,'2025-02-27','Bus03','East Route',20),
(28,'2025-02-27','Bus01','East Route',30),
(29,'2025-02-27','Bus02','Arca Sout Route',25),
(30,'2025-02-27','Bus03','West Route',20),
(31,'2025-02-27','Bus01','Central Route',30),
(32,'2025-02-27','Bus02','North Route',25),
(33,'2025-02-27','Bus03','East Route',20),
(34,'2025-02-27','Bus04','West Route',15),
(35,'2025-02-27','Bus05','South Route',18),
(37,'2025-02-27','Bus07','Uptown Route',28);
/*!40000 ALTER TABLE `bus_passenger_data` ENABLE KEYS */;

--
-- Table structure for table `bus_stop_details`
--

DROP TABLE IF EXISTS `bus_stop_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_stop_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_no` varchar(10) NOT NULL,
  `passenger_count` int(11) NOT NULL,
  `eta` varchar(10) NOT NULL,
  `bus_number` varchar(10) NOT NULL,
  `route` varchar(255) DEFAULT NULL,
  `current_stop` varchar(255) NOT NULL,
  `next_stop` varchar(255) NOT NULL,
  `end_point` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_bus_no` (`bus_no`)
) ENGINE=InnoDB AUTO_INCREMENT=12542 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_stop_details`
--

/*!40000 ALTER TABLE `bus_stop_details` DISABLE KEYS */;
INSERT INTO `bus_stop_details` VALUES
(2,'Bus01',0,'7','Bus01','Central Route','On Route','Unknown','University Parkway','2025-03-18 21:30:30',14.5285140,121.0538790);
/*!40000 ALTER TABLE `bus_stop_details` ENABLE KEYS */;

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `driver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `rfid_tag` varchar(50) NOT NULL,
  `contact_info` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `rfid_tag` (`rfid_tag`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver`
--

/*!40000 ALTER TABLE `driver` DISABLE KEYS */;
INSERT INTO `driver` VALUES
(1,'judy','35F83302','judy@g.com','2024-11-25 19:41:55'),
(2,'malahay','53357F23','malahay@example.com','2024-11-25 19:41:55'),
(3,'test','4038d14','test@example.com','2024-11-25 19:41:55');
/*!40000 ALTER TABLE `driver` ENABLE KEYS */;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drivers` (
  `driver_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rfid_tag` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image` varchar(255) DEFAULT NULL,
  `bus_id` varchar(10) DEFAULT NULL,
  `route` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`driver_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `rfid_tag` (`rfid_tag`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
INSERT INTO `drivers` VALUES
(1,'John Doe','john.doe@example.com','$2y$10$eImiTXuWVxfM37uY4JANjQ==','RFID123456','2024-11-24 16:54:13','uploads/bgbg.jpg','Bus06','ARCA South Route'),
(2,'Jane Smith','jane.smith@example.com','$2y$10$eImiTXuWVxfM37uY4JANjQ==','RFID654321','2024-11-24 16:54:13','uploads/bbbgg.jpg','Bus03','East Route'),
(3,'Alice Johnson','alice.johnson@example.com','$2y$10$eImiTXuWVxfM37uY4JANjQ==','35F83302','2024-11-24 16:54:13','uploads/bbbgg.jpg','Bus03','North Route'),
(4,'JudyMalahay','judymalahay@gmail.com','$2y$10$E2ZdybdsQt9Qfyu1OxYn1./61WIL59jd.qcQGQCyE.wHTq3.ILVLm','53357F23','2024-11-24 18:00:32','uploads/bbbgg.jpg','Bus03','East Route'),
(10,'asdasdasd','ew@gmail.com','$2y$10$abXJREiI2JUCSZc9WE1Ofu88pQBzyisCC.jKqcpxf/4NADJjDM4qO','213123wqqeq','2025-02-23 07:50:45',NULL,NULL,NULL);
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES
(16,'TEST','EEE','2025-03-18 11:04:59'),
(17,'joshua ngaraq','ngarag na aq flz','2025-03-18 11:51:57'),
(18,'dsad','feedback\r\n','2025-03-18 13:36:37');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_path` varchar(255) NOT NULL,
  `passenger_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `bus_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1278 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES
(1268,'uploads_passenger/67d981ff26381.jpg',3,'2025-03-18 14:23:59','Bus01'),
(1269,'uploads_passenger/67d9820a9211b.jpg',0,'2025-03-18 14:24:10','Bus01'),
(1270,'uploads_passenger/67d98216714ce.jpg',3,'2025-03-18 14:24:22','Bus01'),
(1271,'uploads_passenger/67d98222463c2.jpg',5,'2025-03-18 14:24:34','Bus01'),
(1272,'uploads_passenger/67d9823e96604.jpg',0,'2025-03-18 14:25:02','Bus01'),
(1273,'uploads_passenger/67d9824b67029.jpg',4,'2025-03-18 14:25:15','Bus01'),
(1274,'uploads_passenger/67d982570319e.jpg',3,'2025-03-18 14:25:27','Bus01'),
(1275,'uploads_passenger/67d982651a27e.jpg',4,'2025-03-18 14:25:41','Bus01'),
(1276,'uploads_passenger/67d982710075b.jpg',2,'2025-03-18 14:25:53','Bus01'),
(1277,'uploads_passenger/67d9827e178d8.jpg',0,'2025-03-18 14:26:06','Bus01');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `last_attempt` timestamp NOT NULL DEFAULT current_timestamp(),
  `locked_until` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES
(80,'SasAS','2025-03-11 13:32:31',NULL),
(81,'SasAS','2025-03-11 13:34:33',NULL),
(82,'Qwerty123','2025-03-11 13:38:03',NULL),
(83,'Qwerty123','2025-03-11 13:38:44',NULL),
(87,'SasAS','2025-03-11 14:35:24',NULL),
(111,'test7622','2025-03-15 06:38:55',NULL),
(112,'test7622','2025-03-15 06:38:59',NULL),
(113,'test7622','2025-03-15 06:39:04','2025-03-14 23:42:04'),
(115,'Qwerty12345','2025-03-18 13:53:49',NULL),
(116,'Qwerty12345','2025-03-18 13:54:00',NULL),
(117,'Qwerty12345','2025-03-18 13:54:09','2025-03-18 13:57:09');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;

--
-- Table structure for table `maintenance_data`
--

DROP TABLE IF EXISTS `maintenance_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintenance_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_id` varchar(50) NOT NULL,
  `model` varchar(100) NOT NULL,
  `last_maintenance` date NOT NULL,
  `TypeofMaintenance` varchar(100) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `odometer_at_maintenance` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_data`
--

/*!40000 ALTER TABLE `maintenance_data` DISABLE KEYS */;
INSERT INTO `maintenance_data` VALUES
(20,'Bus01','','2025-02-26','Tire replacement','Done',123232115),
(21,'Bus03','','2025-02-26','Brake replacement','Done',123232115),
(22,'Bus02','','2025-02-26','Oil change','Done',123232115),
(23,'Bus01','','2025-02-26','Oil change','Done',123232115),
(24,'Bus01','','2025-02-26','Oil change','Done',123232115),
(25,'Bus01','','2025-02-26','Brake replacement','Done',123232115),
(26,'Bus01','','2025-02-26','Tire replacement','Done',123232115),
(27,'Bus03','','2025-02-26','Brake replacement','Done',123123123),
(28,'Bus01','','2025-03-17','Tire replacement','Done',12312315),
(29,'Bus01','','2025-03-17','Tire replacement','Done',12312315);
/*!40000 ALTER TABLE `maintenance_data` ENABLE KEYS */;

--
-- Table structure for table `passenger_data`
--

DROP TABLE IF EXISTS `passenger_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passenger_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `route` varchar(50) NOT NULL,
  `passengers` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passenger_data`
--

/*!40000 ALTER TABLE `passenger_data` DISABLE KEYS */;
INSERT INTO `passenger_data` VALUES
(1,'2025-11-02','Central Route',1200),
(2,'2024-11-03','Central Route',1500),
(3,'2024-11-04','Central Route',1800),
(4,'2024-11-05','Central Route',2000),
(5,'2024-11-06','Central Route',1700),
(6,'2024-11-07','Central Route',1300),
(7,'2024-11-08','Central Route',1600),
(8,'2024-11-02','North Route',1300),
(9,'2024-11-03','North Route',1600),
(10,'2024-11-04','North Route',1900),
(11,'2024-11-05','North Route',2100),
(12,'2024-11-06','North Route',1800),
(13,'2024-11-07','North Route',1400),
(14,'2024-11-08','North Route',1700),
(15,'2024-11-02','East Route',1100),
(16,'2024-11-03','East Route',1400),
(17,'2024-11-04','East Route',1700),
(18,'2024-10-05','East Route',1900),
(19,'2024-11-06','East Route',1600),
(20,'2024-11-07','East Route',1200),
(21,'2024-11-08','East Route',1500),
(22,'2024-11-02','West Route',1000),
(23,'2024-11-03','West Route',1300),
(24,'2024-11-04','West Route',1600),
(25,'2024-11-05','West Route',1800),
(26,'2024-11-06','West Route',1500),
(27,'2024-11-07','West Route',1100),
(28,'2024-11-08','West Route',1400),
(29,'2024-11-02','ARCA South Route',900),
(30,'2024-11-03','ARCA South Route',1200),
(31,'2024-11-04','ARCA South Route',1500),
(32,'2024-11-05','ARCA South Route',1700),
(33,'2024-11-06','ARCA South Route',1400),
(34,'2024-11-07','ARCA South Route',1000),
(35,'2024-11-08','ARCA South Route',1300),
(36,'2024-11-02','Weekend Route',800),
(37,'2024-11-03','Weekend Route',1100),
(38,'2024-11-04','Weekend Route',1400),
(39,'2024-11-05','Weekend Route',1600),
(40,'2024-11-06','Weekend Route',1300),
(41,'2024-11-07','Weekend Route',900),
(42,'2024-11-08','Weekend Route',1200),
(43,'2024-11-01','Central Route',120),
(44,'2024-11-01','North Route',80),
(45,'2024-11-02','Central Route',150),
(46,'2024-11-02','North Route',90),
(47,'2024-11-02','East Route',60),
(48,'0000-00-00','[Central]',0);
/*!40000 ALTER TABLE `passenger_data` ENABLE KEYS */;

--
-- Table structure for table `routes`
--

DROP TABLE IF EXISTS `routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routes`
--

/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_number` varchar(50) NOT NULL,
  `driver1_name` varchar(255) NOT NULL,
  `driver1_shift` enum('morning','afternoon') NOT NULL,
  `driver2_name` varchar(255) NOT NULL,
  `driver2_shift` enum('morning','afternoon') NOT NULL,
  `route` enum('ARCA South Route','Central Route','East Route','North Route','Weekend Route','West Route') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES
(1,'Bus01','asdas','morning','asdasd','morning','ARCA South Route','2025-03-09 15:05:34'),
(2,'dasdas','asdas','morning','asdasd','morning','ARCA South Route','2025-03-09 15:07:47');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;

--
-- Table structure for table `shift_log`
--

DROP TABLE IF EXISTS `shift_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `driver_id` (`driver_id`),
  CONSTRAINT `shift_log_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_log`
--

/*!40000 ALTER TABLE `shift_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_log` ENABLE KEYS */;

--
-- Table structure for table `shift_logs`
--

DROP TABLE IF EXISTS `shift_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `bus_id` varchar(10) DEFAULT NULL,
  `shift_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `route` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `driver_id` (`driver_id`),
  KEY `bus_id` (`bus_id`),
  CONSTRAINT `fk_bus_id` FOREIGN KEY (`bus_id`) REFERENCES `bus_details` (`bus_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `shift_logs_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`driver_id`),
  CONSTRAINT `shift_logs_ibfk_2` FOREIGN KEY (`bus_id`) REFERENCES `bus_details` (`bus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_logs`
--

/*!40000 ALTER TABLE `shift_logs` DISABLE KEYS */;
INSERT INTO `shift_logs` VALUES
(14,1,'Bus01','2024-11-25','08:00:00','16:00:00','Time In','Central Route'),
(15,2,'Bus02','2024-11-25','09:00:00','17:00:00','Time In','North Route'),
(16,3,'Bus03','2024-11-25','10:00:00','18:00:00','Time In','East Route'),
(17,1,'Bus01','2024-11-26','08:00:00','16:00:00','Time Out','Central Route'),
(18,2,'Bus02','2024-11-26','09:00:00','17:00:00','Time Out','North Route'),
(19,3,'Bus03','2024-11-26','10:00:00','18:00:00','Time Out','East Route');
/*!40000 ALTER TABLE `shift_logs` ENABLE KEYS */;

--
-- Table structure for table `shiftlogs`
--

DROP TABLE IF EXISTS `shiftlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shiftlogs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_id` int(11) NOT NULL,
  `bus_id` varchar(10) NOT NULL,
  `shift_date` datetime NOT NULL,
  `status` varchar(10) NOT NULL,
  `route` varchar(255) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shiftlogs`
--

/*!40000 ALTER TABLE `shiftlogs` DISABLE KEYS */;
INSERT INTO `shiftlogs` VALUES
(128,4,'0','2025-03-18 12:08:17','Time In','North Route'),
(129,4,'0','2025-03-18 12:08:38','Time Out','North Route'),
(130,4,'0','2025-03-18 12:08:57','Time In','North Route'),
(131,4,'0','2025-03-18 13:07:01','Time In','North Route'),
(132,4,'0','2025-03-18 13:20:19','Time In','North Route'),
(133,4,'0','2025-03-18 13:22:52','Time Out','North Route'),
(134,4,'0','2025-03-18 13:31:03','Time In','North Route'),
(135,4,'0','2025-03-18 13:37:22','Time Out','North Route'),
(136,4,'0','2025-03-18 13:37:32','Time In','North Route'),
(137,4,'0','2025-03-18 13:37:43','Time Out','North Route');
/*!40000 ALTER TABLE `shiftlogs` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('SuperAdmin','MidAdmin','Admin') NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Test123','$2y$10$N1s2vXbnlYaGbYhVYlVZA.whaC2G6hVCvMfCJwtw8x/pwRG/E.MXy','SuperAdmin',''),
(2,'Test1234','$2y$10$qi.FD9oc.PxVoVdErGiDPOlZg/o3X6iK1LTQPjqUkzg/mJbzGDqwS','MidAdmin',''),
(3,'Test12345','$2y$10$qMKeC7Egf7zjfdLwTDaFIuClEy/exlo/J87aOYxYlFGPvNNB6NgPa','Admin','karenclairerolle@gmail.com'),
(5,'SasAS','$2y$10$3axb5n8AxIObGr3o8USczejEoVIrUKuYLRcNb2GR/b.D/GBVNTAqS','SuperAdmin','krolle.a12138675@umak.edu.ph'),
(7,'Test123456','$2y$10$97qIFWt9J/PLyJiqX8T3/OtOe.0nSq3MLvu7Wc6rP4rC7DiJh99hu','SuperAdmin','secoxoc186@erapk.com'),
(8,'test4','$2y$10$wi99rf9erF9WOCStOYGpr.wemvkjSVJcU.5UUj0VaufJ7DiblqrnK','Admin','weqwe@gmail.com'),
(10,'test76','$2y$10$/mJ1fx.RooKb0a21zrSSxOhwQo7h9aHPMg1YELPojFEU5aaZkA04G','Admin','weq2312we@gmail.com'),
(15,'test7622','$2y$10$X4oYaFNNfZDCFUrofeaKFOKJuKJ6dYriZDCACrCIoY72j5lGbKAwi','MidAdmin','weq23d12we@gmail.com'),
(16,'test7622yhg','$2y$10$kXFqn0dmU4JXTctzmiKIquq0MQ8oVfsWUHvGMA5.E7ElrgqUodrlS','MidAdmin','weq23d12wde@gmail.com'),
(18,'Kaldrx','$2y$10$pxXK9hI0KOlMXZJ95p03wOpG.MNaQsL4GU77KBN88H3OR6pPxkxYO','Admin','joshuaracelis619@gmail.com'),
(19,'Qwerty123','$2y$10$97qIFWt9J/PLyJiqX8T3/OtOe.0nSq3MLvu7Wc6rP4rC7DiJh99hu','Admin','secoxoc186@erapk.com'),
(20,'Qwerty12345','$2y$10$RNzR1l0YzQ396rDxRHG5BeHYnoClxZNEIPDASSqHs6MCvfjWDQ32W','Admin','secoxoc186@erapk.com');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

--
-- Dumping routines for database 'u537987570_bgc_database'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-18 15:10:48
